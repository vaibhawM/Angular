import { Component, OnInit } from '@angular/core';
import {Pipe, PipeTransform} from '@angular/core';
import { Order } from './order.model';


@Pipe ({
  name : 'TotalPipes'
})
// @Component({
//   selector: 'app-total-pipes',
//   templateUrl: './total-pipes.component.html',
//   styleUrls: ['./total-pipes.component.css']
// })
export class TotalPipesComponent implements OnInit {
  
  transform(total:Order[],gtotal:number) {
    if(!total || !gtotal)
    {
return total;
    }
 return total.filter(x=>x.GTotal>=gtotal);
}
  constructor() { }

  ngOnInit() {
  }
 
  
 
 
}
