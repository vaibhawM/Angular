import { Injectable } from '@angular/core';
import { Order } from './order.model';
import { OrderItemsComponent } from '../orders/order-items/order-items.component';
import { OrderItem } from './order-item.model';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  formData:Order;
  orderItem:OrderItem[];
  constructor(private http:HttpClient) { }
  saveOrUpdateOrder()
  {
    var body =
    {
      ...this.formData,
      OrderItems:this.orderItem
    };
      return  this.http.post(environment.apiURL+'/Ordertbls',body);
  }
  getOrderList()
   {
   
     return this.http.get(environment.apiURL+'/Ordertbls').toPromise()
    
   }

   getOrderById(id:number):any
   {
   
     return this.http.get(environment.apiURL+'/Ordertbls/'+id).toPromise()
    
   }
   deleteOrder(id:number)
   {
   
     return this.http.delete(environment.apiURL+'/Ordertbls/'+id).toPromise()
    
   }
}
