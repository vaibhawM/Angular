import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { getNumberOfCurrencyDigits } from '@angular/common';
import { Register } from './register.model';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {
  formData:Register;
  list:Register[];
  

  constructor(private http:HttpClient) { }

  postRegister(formData:Register)
  {
    
    return this.http.post(environment.apiURL+'/Registers',formData);
  }

  refreshList():void
  {
    
    this.http.get(environment.apiURL+'/Registers')
   .toPromise().then(res=>this.list=res as Register[]);
  }

  putRegister(formData:Register)
  {
  const headers = new HttpHeaders().set('content-type', 'application/json');{{debugger}}
  const params = new HttpParams().set('ID', formData.rId.toString());
   {
     return this.http.put<Register>(environment.apiURL+'/Registers/'+formData.rId,formData,{headers,params});
   }
  }
   
   deleteRegister(id:number)
   {
     return this.http.delete(environment.apiURL+'/Registers/'+id);
   }
  
}
