export class OrderItem {

    orderItemId:number;
     orderId:number;
     Itemid :number;
     quantity:number;
     ItemName:string;
     Price:number;
     Total:number;
   
}
