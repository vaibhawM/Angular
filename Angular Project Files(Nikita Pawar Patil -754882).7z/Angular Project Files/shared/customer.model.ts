export class Customer {
customerId:number;
  Name:string;
}
