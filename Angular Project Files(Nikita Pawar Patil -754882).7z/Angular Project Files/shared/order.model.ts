export class Order {

   orderId:number;
   OrderNumber:string;
   customerId:number;
   PayMethod :string;
   GTotal:number;
   DeletedOrderItemIDs:string;//For delete the record 
}
