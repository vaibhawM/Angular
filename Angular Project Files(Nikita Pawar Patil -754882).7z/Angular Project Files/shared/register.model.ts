export class Register {

       rId:number;
      firstName:string;
      lastName:string;
      Email :string;
      Password:string;
      cPassword:string;//For delete the record 
   }
   