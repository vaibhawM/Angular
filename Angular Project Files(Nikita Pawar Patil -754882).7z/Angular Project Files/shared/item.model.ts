export class Item {
    Itemid:number;
    ItemName:string;
    Price:number;
}
