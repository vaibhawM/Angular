import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { RegisterService } from '../shared/register.service';
import { Register} from '../shared/register.model';
import { ToastrService } from 'ngx-toastr';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  // public Register:loginarray[];
  loginarray: Register[]; 
 
  constructor(private service:RegisterService,private toastr:ToastrService,private router:Router) { }

  ngOnInit() {
    this.service.refreshList();
    this.service.formData={
      rId:null,
      firstName:null,
      lastName:null,
      Email :null,
      Password:null,
      cPassword:null
    }

  }
  


  login(form:NgForm)
  {
   
    console.log(form.value.Email);
    console.log(form.value.Password);
 
  this.loginarray=this.service.list.filter(e=>e.Email==form.value.Email && e.Password==form.value.Password);
  if(this.loginarray.length==0)
  {
    this.toastr.success("Something went wrong","invalid User");
  }
  else
  {
    this.toastr.success("Login Successfully","Valid User");
   this.router.navigate(['/order']);
    
  }
  }

}
