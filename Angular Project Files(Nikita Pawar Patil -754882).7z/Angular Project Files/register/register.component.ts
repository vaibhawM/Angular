// import { Component, OnInit } from '@angular/core';
// import { Register } from '../shared/register.model';
// import { ToastrService } from 'ngx-toastr';
// import { RegisterService } from '../shared/register.service';
// import { NgForm } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { RegisterService } from '../shared/register.service';
import { NgForm, NgFormSelectorWarning } from '@angular/forms';
import { MockNgModuleResolver } from '@angular/compiler/testing';
import {HttpClient} from '@angular/common/http';
import { Register } from '../shared/register.model';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  public RId:number[];
  public result:any;
  registerid:number;
  reg:Register;
  constructor(private service:RegisterService,private toastr:ToastrService,private router:Router) { 
    this.service.formData={
      rId:null,
      firstName:null,
      lastName:null,
      Email:null,
      Password:null,
      cPassword:null
    }
     this.result=this.service.list;
  }

  ngOnInit(){
     
    this.resetForm();
  }


  OnSubmit(form:NgForm)
  { 
    {{debugger}}
    console.log(form.value.rId);
    console.log(form.value.firstName);
    console.log(form.value.lastName);
    console.log(form.value.Email);
    console.log(form.value.Password);
    console.log(form.value.cPassword);
//  this.RId=form.value.rId;
//  this.reg=this.service.list.find(e=>e.rId==this.registerid);


 
  if(this.reg==null)
  // if(form.value.eid=this.employeeid)
   {
    this.InsertRecord(form);
    this.router.navigate(['/login']);
   }
   else
   {
     this.UpdateRecord(form);
     
   }
}

InsertRecord(form:NgForm)
{
 
this.service.postRegister(form.value).subscribe(res=>{
this.toastr.success("Inserted Successfully","You are Registered Successfully");
this.resetForm(form)
this.service.refreshList();
});
}

UpdateRecord(form:NgForm)
  {
    
  this.service.putRegister(form.value).subscribe(res=>{
    this.toastr.warning("Updated Successfully","You are Registered Successfully");
  this.resetForm(form)
  this.service.refreshList();
});
}

resetForm(form?:NgForm)
{
  if(form!=null)
  { 
  form.resetForm();
  this.service.formData={ 
      rId:null,
      firstName:null,
      lastName:null,
      Email:null,
      Password:null,
      cPassword:null
  }
  
}
 }
}












